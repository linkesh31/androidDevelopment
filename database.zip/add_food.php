<?php
header('Content-Type: application/json');
include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Check if all fields are set
    if (isset($_POST['food_name']) && isset($_POST['expiry_date']) && isset($_POST['quantity']) && isset($_POST['category']) && isset($_POST['note']) && isset($_POST['location'])) {
        
        $food_name = $_POST['food_name'];
        $expiry_date = $_POST['expiry_date'];
        $quantity = (int) $_POST['quantity']; // Ensure quantity is an integer
        $category = $_POST['category'];
        $note = $_POST['note'];
        $location = $_POST['location'];

        // Validate date format (optional but recommended)
        if (DateTime::createFromFormat('Y-m-d', $expiry_date) === false) {
            echo json_encode(["status" => "error", "message" => "Invalid date format"]);
            exit();
        }

        // Insert food details into the database
        $stmt = $conn->prepare("INSERT INTO food_items (food_name, expiry_date, quantity, category, note, location, status) VALUES (?, ?, ?, ?, ?, ?, 'available')");
        $stmt->bind_param("ssssss", $food_name, $expiry_date, $quantity, $category, $note, $location);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Food added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add food"]);
        }

        $stmt->close();
        $conn->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    }

} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
