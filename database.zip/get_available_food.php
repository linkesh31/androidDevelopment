<?php
header('Content-Type: application/json');
include 'db.php'; // Include your database connection

// Fetch all available food items
$result = $conn->query("SELECT food_name, expiry_date, quantity, category, note, location FROM food_items WHERE status = 'available'");

$food_items = array();
while ($row = $result->fetch_assoc()) {
    $food_items[] = [
        "food_name" => $row['food_name'],
        "expiry_date" => $row['expiry_date'],
        "quantity" => $row['quantity'],
        "category" => $row['category'],
        "note" => $row['note'],
        "location" => $row['location']
    ];
}

echo json_encode($food_items);
$conn->close();
?>
