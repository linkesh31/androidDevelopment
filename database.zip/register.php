<?php
header('Content-Type: application/json'); // Ensure the response is JSON
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Assuming you're using plain text passwords for now

    // Check if the email or username already exists
    $checkUser = $conn->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
    $checkUser->bind_param("ss", $email, $username);
    $checkUser->execute();
    $result = $checkUser->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Email or username already exists"]);
    } else {
        // Insert the new user into the database
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password); // Plain text password for now

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User registered successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error registering user"]);
        }

        // Close the prepared statement only if it was used
        $stmt->close();
    }

    // Close the user check statement
    $checkUser->close();
}

$conn->close();
?>
