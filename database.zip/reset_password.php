<?php
header('Content-Type: application/json');
include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email']) && isset($_POST['newPassword'])) {
        $email = $_POST['email'];
        $newPassword = $_POST['newPassword'];

        // Check if the email exists in the database
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Email exists, update the password (keeping it plain)
            $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $updateStmt->bind_param("ss", $newPassword, $email);
            $updateStmt->execute();

            if ($updateStmt->affected_rows > 0) {
                echo json_encode(["status" => "success", "message" => "Password reset successful"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to reset password"]);
            }
            $updateStmt->close();
        } else {
            echo json_encode(["status" => "error", "message" => "Email does not exist"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    }
}

$conn->close();
?>
