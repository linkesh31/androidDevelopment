<?php
header('Content-Type: application/json');
include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $food_id = $_POST['food_id'];  // Get the food item ID

    // Update the food status to 'taken'
    $stmt = $conn->prepare("UPDATE food_items SET status = 'taken' WHERE id = ?");
    $stmt->bind_param("i", $food_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Food marked as taken"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to mark food as taken"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
