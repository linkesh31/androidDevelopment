<?php
header('Content-Type: application/json'); // Ensure response is JSON
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include the database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if POST parameters are set
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Prepare and execute query to check if email exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // If user is found
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Compare plain text password
            if ($password == $user['password']) {
                // Return success status with username
                echo json_encode([
                    "status" => "success", 
                    "message" => "Login successful", 
                    "username" => $user['username']
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Invalid password"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "User not found"]);
        }
        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    }
}

$conn->close();
?>
