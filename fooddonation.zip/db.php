<?php
header('Content-Type: application/json'); // Ensure response is JSON
header("Access-Control-Allow-Origin: *");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost"; // XAMPP local server
$user = "root"; // Default MySQL username
$pass = ""; // Default MySQL password (usually empty)
$db = "fooddonation_db"; // Your database name

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}
?>
